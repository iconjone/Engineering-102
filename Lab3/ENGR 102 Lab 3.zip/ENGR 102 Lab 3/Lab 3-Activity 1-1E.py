# By submitting this assignment, all team members agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Names: 	Evan Farkis
# 	 		Emmanuel Garcia
# 	 		Tarik Dawson
#			Jonathan Samuel
# Section:		510
# Assignment:	Lab Assignment 3
# Date:		13 09 2018
# MPH = miles per hour
# MPS = meters per second
userInput = input ("What MPH")
MPH = float (userInput)
MPS = MPH * 0.44704
print (MPS)