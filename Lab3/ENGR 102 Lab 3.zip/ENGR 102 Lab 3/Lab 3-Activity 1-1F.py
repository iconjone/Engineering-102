# By submitting this assignment, all team members agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Names: 	Evan Farkis
# 	 		Emmanuel Garcia
# 	 		Tarik Dawson
#			Jonathan Samuel
# Section:		510
# Assignment:	Lab Assignment 3
# Date:		13 09 2018
userInput = input ("What fahrenheit")
fahrenheit = float (userInput)
celsius = (5/9)*(fahrenheit-32)
print (celsius)